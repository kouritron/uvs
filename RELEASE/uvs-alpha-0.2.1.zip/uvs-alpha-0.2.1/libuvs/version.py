
__version__ = '0.2.1 alpha'




def get_version():
    """ Return the current version of uvs as string. """

    return __version__