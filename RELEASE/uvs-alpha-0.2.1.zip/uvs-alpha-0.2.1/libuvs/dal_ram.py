

import os







if '__main__' == __name__:
    print "hi"


